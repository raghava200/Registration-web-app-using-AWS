# AWS-SERVERLESS-RESGISTRATION-WEBAPP
Building a serverless registration web app by using AWS services

Step 1: Hosting Application in S3 Bucket

Step 2: Grant CDN(cloud distribution) Infront of S3.

Step 3: Access application with CDN.

Step 3: Create a DynamoDB table.

Step 4: Create IAM role for Lambda function

Step 5: Create Lambda function

Step 6: Write Lambda function

Step 7: Create API gateway and enable CORS

Step 8: Test the project
